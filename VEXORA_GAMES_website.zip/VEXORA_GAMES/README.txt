VEXORA GAMES — Setup guide
===========================

WHAT'S INCLUDED
- index.html: the website
- firestore.rules: public game listing, admin-only changes
- storage.rules: public downloads, admin-only uploads/deletes

IMPORTANT
This project is a front-end starter. Online uploads need a Firebase project and
Firebase Storage enabled. Firebase Storage may require a paid billing plan
depending on current Firebase policy, region, and project status. Check the
Firebase console before enabling billing. Do not add a payment method without
the account owner's permission. Large APK downloads/uploads can use bandwidth
and storage quota.

SETUP
1. Create a Firebase project at https://console.firebase.google.com/
2. Register a Web App in Project settings and copy its Firebase config.
3. Enable Authentication > Sign-in method > Google.
4. Create a Firestore database.
5. Enable Firebase Storage if available for your project.
6. Open index.html in a text editor. Replace the values in firebaseConfig:
   apiKey, authDomain, projectId, storageBucket, messagingSenderId, appId.
7. Publish firestore.rules in Firestore Database > Rules.
8. Publish storage.rules in Storage > Rules.
9. Sign in to the website once using your Google account.
10. In browser developer tools, find your Firebase Auth user UID
    (Firebase Console > Authentication > Users also shows it).
11. Replace PASTE_YOUR_GOOGLE_UID_HERE in BOTH rules files and
    PASTE_YOUR_GOOGLE_UID_HERE in index.html's ADMIN_UIDS array.
12. Publish the updated rules again. Sign out and sign back in.
13. Host index.html on a static HTTPS host (for example Firebase Hosting,
    GitHub Pages, or another static web host).

ADMIN ACCESS
Only the Google account UID added to ADMIN_UIDS and the two security rules
can upload/delete games. Do not share the admin UID list as a substitute for
the security rules. Never publish Firebase service-account keys in this site.

NOTE
- Public visitors can view the game list and download uploaded APKs.
- Upload only APK files you own or have permission to distribute.
- Android may warn users before installing APKs from outside the Play Store.
- Test with a small APK first. This starter does not scan uploaded files for malware.
- The optional cover image is limited to 5 MB by the supplied Storage rules.
